# docutils

A copy of docutils python library to use only with python3

This version of docutils is created to build android apps with Kivy that need Rst and uses python3crystax package.


